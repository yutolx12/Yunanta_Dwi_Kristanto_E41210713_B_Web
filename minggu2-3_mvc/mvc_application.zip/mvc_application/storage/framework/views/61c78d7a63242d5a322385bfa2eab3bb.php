<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid">
        <div clsas="container">
            <h1 class="display-4">Home Page</h1>
            <p class="lead"> This is the Home Page</p>
        </div>
        <p>Nama: <?php echo e($nama); ?></p>
        <p>Matkul</p>
        <ul>
            <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($m); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /srv/http/kuliah/semester4/web/minggu3_mvc/mvc_application/resources/views/home.blade.php ENDPATH**/ ?>